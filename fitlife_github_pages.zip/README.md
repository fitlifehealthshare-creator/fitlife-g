# FitLife Growth Strategy (GitHub Pages)

This package is ready for GitHub Pages.

## Quick Publish (No Code)
1. Create a **public** repo (e.g., `fitlife-growth`).
2. Upload **index.html** and **logo-fitlife.svg** to the repo **root**.
3. Go to **Settings → Pages**.
4. **Source**: Deploy from a branch → **Branch: `main`** → **Folder: `/ (root)`** → **Save**.
5. Open: `https://YOUR-USERNAME.github.io/fitlife-growth/`

## Update
Upload a new `index.html` with the same name and commit.
